//Initializes the canvas to A4 size and the default layout
function initCanvas(){
    setCanvasSize("A4");

    var canvas = document.getElementById("certificateCanvas");    
    var ctx = canvas.getContext("2d");
    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    setLayout("default");
}

//Changes the canvas size to a pre-defined set of values. NOTE: resets the context
function setCanvasSize(sizeId){    
    var canvas = document.getElementById("certificateCanvas");   

    switch(sizeId.toLowerCase()){
        case "a4":
            canvas.setAttribute("width", 1050);
            canvas.setAttribute("height", 1485);
            //TODO: make scaling more intuitive (CSS scaling distorts the canvas)
            break;
        //TODO: add other sizes
    }
}

//Loads the assets and arranges the canvas according to the pre-defined layout
function setLayout(layoutId){
    var canvas = document.getElementById("certificateCanvas");
    var ctx = canvas.getContext("2d");
    switch(layoutId.toLowerCase()){
        case "default":
            ctx.drawImage(document.getElementById("canvasBackground"),0,0);
            addSvg(120, 90, "img/Groove logo L.svg");            
            break;            
        //TODO: add other layout definitions
    }
}