//Adds an SVG image to the canvas with the pre-defined size and location
function addSvg(inPosX, inPosY, imgPath){
    //Load the SVG into a temp node
    /*var tempSvgNode = document.createElement("object"); 
    tempSvgNode.setAttribute("data", imgPath);
    tempSvgNode.setAttribute("type", "image/svg+xml");        
    tempSvgNode.setAttribute("id", "tempSvgNode");    
    var assets = document.getElementById("assets");
    assets.appendChild(tempSvgNode);


    
    var xml = new XMLSerializer().serializeToString(document.getElementById("tempSvgNode"));       
    var svg64 = btoa(xml);
    
    //Prepend a "header"
    var b64Start = 'data:image/svg+xml;base64,';
    var image64 = b64Start + svg64;*/

    //Set the serialized SVG as the source of the img element
    var img = new Image();
    img.src = imgPath;
    var canvas = document.getElementById("certificateCanvas");
    var ctx = canvas.getContext("2d");
    
    //Draw the image onto the canvas
    ctx.drawImage(img, inPosX, inPosY);
}